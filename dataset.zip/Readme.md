Cleaned the drugbank data.

# Included

type                          15235
created                       15235
updated                       15235
drugbank-id                   16166
name                          16166
description                   12929
cas-number                     9553
unii                          10934
average-mass                  11586
monoisotopic-mass             11586
state                          9171
groups                        15235
synthesis-reference            1604
indication                     4174
pharmacodynamics               3042
mechanism-of-action            3913
toxicity                       2432
metabolism                     2297
absorption                     2399
half-life                      2372
protein-binding                1885
route-of-elimination           1983
volume-of-distribution         1681
clearance                      1561
atc-codes                      3403
ahfs-codes                        0
pdb-entries                    5940
fda-label                      1216
msds                           1492
food-interactions              1378
drug-interactions              4478
sequences                       267
enzymes                        1980
pathways                          0
reactions                       320
snp-effects                      41
snp-adverse-drug-reactions       17
targets                        7296
carriers                        497
transporters                    804


# Excluded

general-references
classification
salts
synonyms
products
international-brands
mixtures
packagers
manufacturers
prices
categories
affected-organisms
dosages
patents
calculated-properties
experimental-properties
external-identifiers
external-links
